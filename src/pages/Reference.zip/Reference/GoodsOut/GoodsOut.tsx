import React from 'react'

function GoodsOut() {
  return (
    <div>Tovarlar chiqimi</div>
  )
}
export default GoodsOut