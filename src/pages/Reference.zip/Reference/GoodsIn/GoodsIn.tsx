import React from 'react'

function GoodsIn() {
  return (
    <div>Tovarlar kirimi</div>
  )
}

export default GoodsIn;