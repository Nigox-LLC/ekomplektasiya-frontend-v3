import React from 'react'

function ReferenceRequisites() {
  return (
    <div>ReferenceRequisites</div>
  )
}

export default ReferenceRequisites