import React from 'react'

function WareHouseTransfer() {
  return (
    <div>WareHouseTransfer</div>
  )
}
export default WareHouseTransfer;