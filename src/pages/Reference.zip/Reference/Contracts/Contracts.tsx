import React from 'react'

function Contracts() {
  return (
    <div>Contracts</div>
  )
}

export default Contracts;