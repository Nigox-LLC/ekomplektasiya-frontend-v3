import React from 'react'

function YearPlan() {
  return (
    <div>YearPlan</div>
  )
}

export default YearPlan